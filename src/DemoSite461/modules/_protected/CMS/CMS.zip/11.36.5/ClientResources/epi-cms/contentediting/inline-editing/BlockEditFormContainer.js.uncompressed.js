define("epi-cms/contentediting/inline-editing/BlockEditFormContainer", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/topic",
    "dojo/on",
    "dojo/Evented",
    "epi/dependency",
    "epi",
    "epi/UriParser",
    "epi/shell/tooltipHider",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/ContentViewModel",

    "epi/shell/widget/FormContainer"
], function (
    declare,
    Deferred,
    topic,
    on,
    Evented,
    dependency,
    epi,
    UriParser,
    tooltipHider,
    ContentActionSupport,
    ContentViewModel,
    FormContainer) {

    return declare([FormContainer, Evented], {
        contentLink: null,
        isDirty: false,
        initialValue: null,

        _onIsDirty: function () {
            var isDirty = !epi.areEqual(this.get("initialValue"), this.get("value"));

            this.set("isDirty", isDirty);
            this.emit("isDirty", isDirty);
        },

        postCreate: function () {
            this.inherited(arguments);

            this._enhancedStore = dependency.resolve("epi.storeregistry").get("epi.cms.latestcontentversion");
            this.own(on(this, "FormCreated", function () {
                tooltipHider(this.form.getParent());
                this.onChange = this._onIsDirty.bind(this);

                this.own(on(this, "change", this._onIsDirty.bind(this)));
                this.own(on(this.domNode, "change", this._onIsDirty.bind(this)));
                this.own(on(this.domNode, "keyup", this._onIsDirty.bind(this)));
                this.initialValue = this.get("value");
            }.bind(this)));
        },

        onFieldCreated: function (fieldName, widget) {
            this.inherited(arguments);
            // make sure _model is not null before set _contentLink
            // e.g: CreateNewBlockEditFormContainer
            this._model && widget.set("_contentLink", this._model.contentLink);
        },

        saveForm: function () {
            var model = this._model,
                value = this.value,
                initialValue = this.initialValue;

            // the form was not changed
            if (!this.value) {
                return new Deferred().resolve(false);
            }

            this._model.onContentLinkChange = function () { };

            Object.keys(this.value).forEach(function (propertyName) {
                if (value[propertyName] !== initialValue[propertyName]) {
                    model.setProperty(propertyName, value[propertyName]);
                }
            });

            return model.save().then(function (result) {
                if (!result) {
                    return;
                }
                topic.publish("/epi/cms/content/statuschange/", model.contentData.status, {id: model.contentLink});

                if (model.contentData.isPendingPublish) { /*isPendingPublish is true if the content doesn't have a published version*/
                    topic.publish("/epi/cms/block/inline-updated");
                }
            });
        },

        layout: function () {
            this.inherited(arguments);
            this.containerLayout.containerNode.style.removeProperty("height");
        },

        _setContentLinkAttr: function (contentLink) {
            this._set("contentLink", contentLink);

            var self = this;
            return this._enhancedStore.query({id: contentLink, keepVersion: true}).then(function (latestContent) {
                var contentData = latestContent;
                return self._getContextStore().query({uri: "epi.cms.contentdata:///" + contentData.contentLink})
                    .then(function (context) {
                        var uri = new UriParser(context.uri);
                        self._model = new ContentViewModel({
                            contentLink: uri.getId(),
                            enableAutoSave: false
                        });
                        return self._model.reload(true);
                    })
                    .then(function () {
                        self.set("metadata", self._model.get("metadata"));
                        return contentData;
                    });
            });
        },

        _onFormCreated: function () {
            this.inherited(arguments);

            if (this._model && !this._model.canChangeContent(ContentActionSupport.action.Edit)) {
                this.set("readOnly", true);
            }
        },

        _hideProperty: function (metadata, propertyName) {
            metadata.properties.some(function (property) {
                if (property.name === propertyName) {
                    property.showForEdit = false;
                    return true;
                }
                return false;
            });
        },

        _disableNonLanguageSpecificProperties: function (metadata) {
            metadata.properties.forEach(function (property) {
                if (!property.settings.isLanguageSpecific) {
                    property.showForEdit = false;
                }
            }.bind(this));
        },

        _setMetadataAttr: function (metadata) {
            var settings = (metadata.customEditorSettings || {}).inlineBlock;

            if (!settings) {
                console.warn("Metadata was not initialized properly");
                settings = {};
            }

            if (!settings.showNameProperty) {
                this._hideProperty(metadata, "icontent_name");
            }
            if (!settings.showCategoryProperty) {
                this._hideProperty(metadata, "icategorizable_category");
            }

            if (this.get("isTranslationNeeded")) {
                this._disableNonLanguageSpecificProperties(metadata);
            }

            metadata.properties.forEach(function (property) {
                property.settings.isInQuickEditMode = true;
            }.bind(this));

            var hiddenGroups = settings.hiddenGroups.map(function (x) {
                return x.toLowerCase();
            });
            var numberOfVisibleGroups = metadata.groups.filter(function (x) {
                return x.name !== "EPiServerCMS_SettingsPanel" && hiddenGroups.indexOf(x.name.toLowerCase()) === -1;
            }).length;

            // Change group properties container to epi-cms/layout/CreateContentGroup
            metadata.layoutType = "epi/shell/layout/SimpleContainer";
            metadata.groups.forEach(function (group) {
                group.uiType = "epi-cms/layout/CreateContentGroupContainerNoHeader";

                if (group.name === "EPiServerCMS_SettingsPanel") {
                    group.options = {};
                    group.title = null;
                } else {
                    if (numberOfVisibleGroups > 1) {
                        group.uiType = "epi-cms/layout/CreateContentGroupContainer";
                    }
                }

                // by default Settings tab is not displayed
                if (hiddenGroups.indexOf(group.name.toLowerCase()) !== -1) {
                    group.displayUI = false;
                }
            });
            this._set("metadata", metadata);

            this.startup();
        },

        _getContextStore: function () {
            if (!this._contextStore) {
                var registry = dependency.resolve("epi.storeregistry");
                this._contextStore = registry.get("epi.shell.context");
            }
            return this._contextStore;
        }
    });
});
